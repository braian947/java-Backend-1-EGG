/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author braia
 */
public class ejer4_guia2 {
    
 /*   Dada una cantidad de grados centígrados se debe mostrar su equivalente
    en grados Fahrenheit. La fórmula correspondiente es: F = 32 + (9 * C / 5).*/
public static void main(String[] args) {
    double gradosf;
    int c ;
    Scanner num = new Scanner(System.in) ;
    System.out.println("ingrese grados centigrados: ");
    c = num.nextInt();
    gradosf = 32 + (9 * c / 5);
    System.out.println("grados c° en F° son : " + gradosf + " F°");
            
}
}

