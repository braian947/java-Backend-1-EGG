/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author braia
 */
public class ejer5_guia2 {
   /* Escribir un programa que lea un número entero por teclado 
    y muestre por pantalla el doble, el triple y la raíz cuadrada 
    de ese número. */
    public static void main(String[] args) {
        
       int num,doble,triple;
       //double resultado = Math.sqrt(num);
       Scanner leer = new Scanner(System.in) ;
        System.out.println("ingrese un numero entero: ");
        num= leer.nextInt();
        doble=num*2;
        System.out.println("el doble de: "+num+ "es: "+doble);
        triple=num*3;
        System.out.println("el triple de: "+num+ "es: "+triple);
        double raiz = Math.sqrt(num);
        System.out.println("La RAIZ de : "+num+ "es: "+raiz);

                

        
        
    }
    
}
