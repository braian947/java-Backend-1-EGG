
package javaapplication1;

import java.util.Scanner;

/**

 */
public class ejer1_guia2 {
    
     public static void main(String[] args) {
  /*  Escribir un programa que pida dos números enteros por teclado y calcule
    la suma de los dos. El programa deberá después mostrar el resultado 
    de la suma */
    Scanner num = new Scanner(System.in) ;
    int numero1 = 0,numero2 = 0 ;
    int suma;
   
         System.out.println("ingrese un numero1 a sumar:");
         numero1 =  num.nextInt();
         System.out.println("ingrese un numero2 a sumar:");
         numero2 =  num.nextInt();
         suma = numero1 + numero2 ;
         System.out.println(" la suma de los numeros ingresados es: "+ suma);
   
 }
   
}
